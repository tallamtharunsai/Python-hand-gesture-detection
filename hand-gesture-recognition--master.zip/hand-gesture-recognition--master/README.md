# Hand-Numbers-sign-Recognition-using-Opencv-Keras-CNN
-This project is about recognition of hand signs of numbers using CNN model and opencv.
 System requrements 
 -Python 
 -OpenCv
 -Keras
 -numpy
